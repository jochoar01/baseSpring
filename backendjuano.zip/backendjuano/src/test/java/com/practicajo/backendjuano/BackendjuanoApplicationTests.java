package com.practicajo.backendjuano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendjuanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
