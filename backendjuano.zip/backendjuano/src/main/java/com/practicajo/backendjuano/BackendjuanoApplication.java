package com.practicajo.backendjuano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendjuanoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendjuanoApplication.class, args);
	}

}
